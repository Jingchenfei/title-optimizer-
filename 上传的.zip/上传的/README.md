# 社交媒体标题优化器

## 功能
- 输入文章内容自动生成3个社交媒体风格标题
- 纯前端实现，零服务器成本
- 完全响应式设计

## 部署步骤
1. Fork本仓库
2. 进入仓库Settings -> Pages
3. 选择Branch: main, Folder: / (root)
4. 保存后访问生成的GitHub Pages链接